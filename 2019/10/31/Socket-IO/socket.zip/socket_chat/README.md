### 基于flask socket-io实现的live chat，主要是应用于网页客服

- 通过动态添加html来实现的
- 不调用任何数据库插件
- 通过 socket 来实现
