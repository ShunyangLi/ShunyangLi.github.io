from flask import Flask, render_template
from flask_mail import Mail, Message
from threading import Thread

app = Flask(__name__)

app.config['MAIL_SERVER'] = 'smtp.qq.com'
app.config['MAIL_PORT'] = 465
app.config['MAIL_USE_SSL'] = True
app.config['MAIL_USERNAME'] = '123'
app.config['MAIL_PASSWORD'] = 'xxxx'
app.config['MAIL_DEFAULT_SENDER'] = '123@qq.com'

mail = Mail(app)


def async_send_mail(app, msg):
    with app.app_context():
        mail.send(msg)

def send_mail(to, subject, template, **kwargs):
    msg = Message(subject, sender = '123456@qq.com', recipients=[to])
    msg.html = render_template(template + '.html', **kwargs)
    thr = Thread(target=async_send_mail, args=[app, msg])
    thr.start()
    return thr

@app.route('/')
def index():
	send_mail('123@gmail.com', 'Hello', 'index', user="You", url = "shunyangli.github.io")
	return "SUCCESS"