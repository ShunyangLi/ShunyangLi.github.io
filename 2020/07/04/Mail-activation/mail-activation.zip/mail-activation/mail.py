from itsdangerous import TimedJSONWebSignatureSerializer as Serializer
from flask import Flask, render_template, request, session
from flask_mail import Mail, Message
from threading import Thread
import os

app = Flask(__name__)

app.config['SECRET_KEY'] = os.urandom(24)
app.config['MAIL_SERVER'] = 'smtp.qq.com'
app.config['MAIL_PORT'] = 465
app.config['MAIL_USE_SSL'] = True
app.config['MAIL_USERNAME'] = 'xxx'
app.config['MAIL_PASSWORD'] = 'xx'
app.config['MAIL_DEFAULT_SENDER'] = 'xx@qq.com'

mail = Mail(app)

# 异步发送function
def async_send_mail(app, msg):
    # 获取当前程序的上下文
    with app.app_context():
        # 发送邮件
        mail.send(msg)


# 定义发送函数, message的配置和上面讲的一样
# **kwargs 指传进来的参数, 可以传多个参数进来。eg: username = 'xxx', link = 'xxx.com'
def send_mail(to, subject, template, **kwargs):
    msg = Message(subject, sender = 'xx@qq.com', recipients=[to])
    msg.html = render_template(template + '.html', **kwargs)
    thr = Thread(target=async_send_mail, args=[app, msg])
    thr.start()
    # 返回调用的结果
    return thr


def encryption(data, expires_in=3600):
    """
    加密json
    :param data: 需要加密的数据
    :param expires_in: 过期时间
    :return: 返回加密的str
    """
    s = Serializer(app.config['SECRET_KEY'], expires_in=expires_in)
    return s.dumps(data).decode("utf-8")


def decryption(token):
    """
    解密token到json数据
    :param token: 密文
    :return: 解密的数据
    """
    s = Serializer(app.config['SECRET_KEY'])

    try:
        data = s.loads(token)
        return data
    except SignatureExpired:
        print('Token expired')
    except:
        print('Unknown error')


@app.route('/', methods=["POST", "GET"])
def index():

    if request.method == "POST":
        email = request.form.get('email')
        if email is not None:
            session[email] = email
            token = encryption(email)
            send_mail(email, 'Activate you account', 'activate', action_url='127.0.0.1:5000/activate/{}'.format(token))
            return '<h1>success</h1>'
    return render_template('index.html')


@app.route('/activate/<token>', methods=["POST", "GET"])
def check(token):
    if token is None:
        return "False"
    
    email = decryption(token)
    if session.get(email) is None:
        return "False"
    
    return "True"


if __name__ == '__main__':
    app.run(debug=True)
    